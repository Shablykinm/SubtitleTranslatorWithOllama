"""Пакет для перевода субтитров"""
from subtitle_translator.app import SubtitleTranslatorApp

__version__ = "1.0.0"